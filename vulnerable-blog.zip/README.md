Proyecto: vulnerable-blog
Uso: sitio de laboratorio para practicar XSS almacenado (local).

En Windows: puedes probar con XAMPP o WSL + Apache/PHP. En Mint clona y despliega en /var/www.
Repo: mantener privado mientras haces pruebas.
